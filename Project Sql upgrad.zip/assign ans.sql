#1. Create a new table named 'bajaj1' containing the date, close price, 20 Day MA and 50 Day MA. (This has to be done for all 6 stocks)
select *
from `bajaj auto`;
# Bajaj1 Start
SET SQL_SAFE_UPDATES = 0;
alter table `bajaj auto` add Dates date;

update `bajaj auto` set Dates = str_to_date(date, '%d-%M-%Y') ;

create table bajaj1  as (select Dates as'Date',`Close price`as 'Close Price' ,
avg(`Close Price`) over (order by Dates  asc rows 19 preceding) as `20 Day MA` ,
avg(`Close Price`) over (order by Dates  asc rows 49 preceding) as `50 Day MA`from `bajaj auto`);

select *from bajaj1;
# Bajaj1 End

# Eicher Motors
select *from `eicher motors`;
alter table `eicher motors` add Dates date;


update `eicher motors` set Dates = str_to_date(date, '%d-%M-%Y') ;

create table eicher1  as (select Dates as'Date',`Close price`as 'Close Price' ,
avg(`Close Price`) over (order by Dates  asc rows 19 preceding) as `20 Day MA` ,
avg(`Close Price`) over (order by Dates  asc rows 49 preceding) as `50 Day MA`from `eicher motors`);

select *from eicher1;

#Eicher 1 end

#Hero motors Start
select *from `hero motocorp`;
alter table `hero motocorp` add Dates date;


update `hero motocorp`set Dates = str_to_date(date, '%d-%M-%Y') ;

create table Hero1  as (select Dates as'Date',`Close price`as 'Close Price' ,
avg(`Close Price`) over (order by Dates  asc rows 19 preceding) as `20 Day MA` ,
avg(`Close Price`) over (order by Dates  asc rows 49 preceding) as `50 Day MA`from `hero motocorp`);

select *from hero1;

#Hero Motors End

#Infosys Start

select *from infosys;
alter table infosys add Dates date;


update infosys set Dates = str_to_date(date, '%d-%M-%Y') ;

create table infosys1  as (select Dates as'Date',`Close price`as 'Close Price' ,
avg(`Close Price`) over (order by Dates  asc rows 19 preceding) as `20 Day MA` ,
avg(`Close Price`) over (order by Dates  asc rows 49 preceding) as `50 Day MA`from infosys);

select *from infosys1;

#infosys End

#TCS Start

select *from tcs;
alter table tcs add Dates date;


update tcs set Dates = str_to_date(date, '%d-%M-%Y') ;

create table tcs1  as (select Dates as'Date',`Close price`as 'Close Price' ,
avg(`Close Price`) over (order by Dates  asc rows 19 preceding) as `20 Day MA` ,
avg(`Close Price`) over (order by Dates  asc rows 49 preceding) as `50 Day MA`from tcs );

select *from tcs1;

# TCS End

#TVS MOTOR Start

select *from `tvs motors` ;
alter table`tvs motors` add Dates date;


update `tvs motors` set Dates = str_to_date(date, '%d-%M-%Y') ;

create table tvs1  as (select Dates as'Date',`Close price`as 'Close Price' ,
avg(`Close Price`) over (order by Dates  asc rows 19 preceding) as `20 Day MA` ,
avg(`Close Price`) over (order by Dates  asc rows 49 preceding) as `50 Day MA`from `tvs motors` );

select *from tvs1;

# TVS End

#2. Create a master table containing the date and close price of all the six stocks. (Column header for the price is the name of the stock)
create table master
select baj.Dates as Date , baj.`Close Price` as Bajaj , t.`Close Price` as TCS , 
tv.`Close Price` as TVS , info.`Close Price` as Infosys , eic.`Close Price` as Eicher , he.`Close Price` as Hero
from `bajaj auto` baj
inner join `tcs` t on t.Dates= baj.Dates
inner join `tvs motors` tv on tv.Dates = baj.Dates
inner join `infosys` info on info.Dates = baj.Dates
inner join `eicher motors` eic on eic.Dates= baj.Dates
inner join `hero motocorp` he on he.Dates = baj.Dates;

select * from master
# End of Question 2
#3. Use the table created in Part(1) to generate buy and sell signal. Store this in another table named 'bajaj2'. 
#Perform this operation for all stocks.


#Create Bajaj2
create table bajaj2 as
select `Date`, `Close Price`,
(case	

	when ROW_NUMBER() over() <=50 THEN 'Hold'

	when (`20 Day MA` - `50 Day MA` > 0 and LAG(`20 Day MA` - `50 Day MA`) over() > 0 ) then 'Hold'

    when(`20 Day MA` - `50 Day MA` < 0 and LAG(`20 Day MA` - `50 Day MA`) over() < 0 ) then'Hold'
  
   when (`20 Day MA` - `50 Day MA` = 0 and LAG(`20 Day MA` - `50 Day MA`) over()  = 0 ) then 'Hold'

   when (`20 Day MA` - `50 Day MA` > 0 and LAG(`20 Day MA` - `50 Day MA`) over() < 0 ) then'Buy'
 
   when (`20 Day MA` - `50 Day MA` < 0 and LAG(`20 Day MA` - `50 Day MA`) over() > 0 ) then'Sell'
end) as `Signal`
from bajaj1;

select * from bajaj2;
#Bajaj2 End

#Create Eicher2
create table eicher2 as
select `Date`, `Close Price`,
(case	

	when ROW_NUMBER() over() <=50 THEN 'Hold'

	when (`20 Day MA` - `50 Day MA` > 0 and LAG(`20 Day MA` - `50 Day MA`) over() > 0 ) then 'Hold'

    when(`20 Day MA` - `50 Day MA` < 0 and LAG(`20 Day MA` - `50 Day MA`) over() < 0 ) then'Hold'
  
   when (`20 Day MA` - `50 Day MA` = 0 and LAG(`20 Day MA` - `50 Day MA`) over()  = 0 ) then 'Hold'

   when (`20 Day MA` - `50 Day MA` > 0 and LAG(`20 Day MA` - `50 Day MA`) over() < 0 ) then'Buy'
 
   when (`20 Day MA` - `50 Day MA` < 0 and LAG(`20 Day MA` - `50 Day MA`) over() > 0 ) then'Sell'
end) as `Signal`
from eicher1;

select * from eicher2;

#Eicher2 End

#Create Hero2
create table hero2 as
select `Date`, `Close Price`,
(case	

	when ROW_NUMBER() over() <=50 THEN 'Hold'

	when (`20 Day MA` - `50 Day MA` > 0 and LAG(`20 Day MA` - `50 Day MA`) over() > 0 ) then 'Hold'

    when(`20 Day MA` - `50 Day MA` < 0 and LAG(`20 Day MA` - `50 Day MA`) over() < 0 ) then'Hold'
  
   when (`20 Day MA` - `50 Day MA` = 0 and LAG(`20 Day MA` - `50 Day MA`) over()  = 0 ) then 'Hold'

   when (`20 Day MA` - `50 Day MA` > 0 and LAG(`20 Day MA` - `50 Day MA`) over() < 0 ) then'Buy'
 
   when (`20 Day MA` - `50 Day MA` < 0 and LAG(`20 Day MA` - `50 Day MA`) over() > 0 ) then'Sell'
end) as `Signal`
from hero1;

select * from hero2;
#Hero2 End

#Create Infosys2
create table infosys2 as
select `Date`, `Close Price`,
(case	

	when ROW_NUMBER() over() <=50 THEN 'Hold'

	when (`20 Day MA` - `50 Day MA` > 0 and LAG(`20 Day MA` - `50 Day MA`) over() > 0 ) then 'Hold'

    when(`20 Day MA` - `50 Day MA` < 0 and LAG(`20 Day MA` - `50 Day MA`) over() < 0 ) then'Hold'
  
   when (`20 Day MA` - `50 Day MA` = 0 and LAG(`20 Day MA` - `50 Day MA`) over()  = 0 ) then 'Hold'

   when (`20 Day MA` - `50 Day MA` > 0 and LAG(`20 Day MA` - `50 Day MA`) over() < 0 ) then'Buy'
 
   when (`20 Day MA` - `50 Day MA` < 0 and LAG(`20 Day MA` - `50 Day MA`) over() > 0 ) then'Sell'
end) as `Signal`
from infosys1;

select * from infosys2;
#Infosys2 End

#Create Tcs2
create table tcs2 as
select `Date`, `Close Price`,
(case	

	when ROW_NUMBER() over() <=50 THEN 'Hold'

	when (`20 Day MA` - `50 Day MA` > 0 and LAG(`20 Day MA` - `50 Day MA`) over() > 0 ) then 'Hold'

    when(`20 Day MA` - `50 Day MA` < 0 and LAG(`20 Day MA` - `50 Day MA`) over() < 0 ) then'Hold'
  
   when (`20 Day MA` - `50 Day MA` = 0 and LAG(`20 Day MA` - `50 Day MA`) over()  = 0 ) then 'Hold'

   when (`20 Day MA` - `50 Day MA` > 0 and LAG(`20 Day MA` - `50 Day MA`) over() < 0 ) then'Buy'
 
   when (`20 Day MA` - `50 Day MA` < 0 and LAG(`20 Day MA` - `50 Day MA`) over() > 0 ) then'Sell'
end) as `Signal`
from tcs1;

select * from tcs2;
#TCS2 End

#Create tvs2
create table tvs2 as
select `Date`, `Close Price`,
(case	

	when ROW_NUMBER() over() <=50 THEN 'Hold'

	when (`20 Day MA` - `50 Day MA` > 0 and LAG(`20 Day MA` - `50 Day MA`) over() > 0 ) then 'Hold'

    when(`20 Day MA` - `50 Day MA` < 0 and LAG(`20 Day MA` - `50 Day MA`) over() < 0 ) then'Hold'
  
   when (`20 Day MA` - `50 Day MA` = 0 and LAG(`20 Day MA` - `50 Day MA`) over()  = 0 ) then 'Hold'

   when (`20 Day MA` - `50 Day MA` > 0 and LAG(`20 Day MA` - `50 Day MA`) over() < 0 ) then'Buy'
 
   when (`20 Day MA` - `50 Day MA` < 0 and LAG(`20 Day MA` - `50 Day MA`) over() > 0 ) then'Sell'
end) as `Signal`
from tvs1;

select * from tvs2;
#Tvs2 End

#Question 3 End

DELIMITER $$

create function bajaj_signal(trade_date Date)
returns varchar(10) deterministic
begin
	declare trade_signal VARCHAR(10);
    select `Signal` 
    from bajaj2 
   where Date = trade_date 
    into trade_signal; 
	return trade_signal;
end $$

DELIMITER ;

 select bajaj_signal('2016-06-20') as `Signal`;
